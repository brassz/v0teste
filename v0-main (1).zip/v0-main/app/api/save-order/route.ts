import { NextResponse } from "next/server"
import { DatabaseService } from "@/lib/database-service"

/**
 * Accepts a JSON body coming from /dealer/new-boat and
 * writes the order to the Supabase `orders` table.
 * The payload already contains `upholstery_package`.
 */
export async function POST(request: Request) {
  try {
    const orderData = await request.json()
    console.log("Received order data:", orderData)

    // Ensure we have an order ID (for older clients that don’t send one)
    const orderId = orderData.orderId || DatabaseService.generateOrderId()

    /* ------------------------------------------------------------------
       Resolve dealer record
    ------------------------------------------------------------------ */
    const dealers = await DatabaseService.getDealers()
    const dealer = dealers.find((d) => d.name === orderData.dealerName)

    if (!dealer || !dealer.id) {
      return NextResponse.json({ success: false, error: "Dealer não encontrado" }, { status: 404 })
    }

    /* ------------------------------------------------------------------
       Map client payload → DB schema
    ------------------------------------------------------------------ */
    const dbOrderData = {
      order_id: orderId,
      dealer_id: dealer.id,
      customer_name: orderData.customer?.name ?? orderData.customer_name ?? "",
      customer_email: orderData.customer?.email ?? orderData.customer_email ?? "",
      customer_phone: orderData.customer?.phone ?? orderData.customer_phone ?? "",
      customer_address: orderData.customer?.address ?? orderData.customer_address ?? "",
      customer_city: orderData.customer?.city ?? orderData.customer_city ?? "",
      customer_state: orderData.customer?.state ?? orderData.customer_state ?? "",
      customer_zip: orderData.customer?.zip ?? orderData.customer_zip ?? "",
      customer_country: orderData.customer?.country ?? orderData.customer_country ?? "",
      boat_model: orderData.model ?? orderData.boat_model ?? "",
      engine_package: orderData.engine ?? orderData.engine_package ?? "",
      hull_color: orderData.hull_color ?? "",
      upholstery_package: orderData.upholstery_package ?? orderData.upholsteryPackage ?? "", // VERIFICAR AMBOS OS NOMES
      additional_options: Array.isArray(orderData.options)
        ? orderData.options
        : Array.isArray(orderData.additional_options)
          ? orderData.additional_options
          : [],
      payment_method: orderData.paymentMethod ?? orderData.payment_method ?? "",
      deposit_amount: Number(orderData.depositAmount ?? orderData.deposit_amount ?? 0),
      additional_notes: orderData.additionalNotes ?? orderData.additional_notes ?? "",
      total_usd: Number(orderData.totalUsd ?? orderData.total_usd ?? 0),
      total_brl: Number(orderData.totalBrl ?? orderData.total_brl ?? 0),
      status: orderData.status ?? "pending",
    }

    console.log("Dados do pedido processados para o banco:", dbOrderData)
    console.log("upholstery_package recebido:", orderData.upholstery_package || orderData.upholsteryPackage)

    /* ------------------------------------------------------------------
       Persist
    ------------------------------------------------------------------ */
    const savedOrder = await DatabaseService.createOrder(dbOrderData)

    /* ------------------------------------------------------------------
       Return
    ------------------------------------------------------------------ */
    return NextResponse.json({
      success: true,
      data: savedOrder,
      orderId,
    })
  } catch (err) {
    console.error("Erro ao salvar pedido:", err)
    return NextResponse.json(
      { success: false, error: err instanceof Error ? err.message : String(err) },
      { status: 500 },
    )
  }
}
