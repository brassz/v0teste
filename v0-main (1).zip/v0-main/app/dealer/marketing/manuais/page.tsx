"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import type { MarketingManual } from "@/lib/database-service"

export default function ManuaisPage() {
  const [manuals, setManuals] = useState<MarketingManual[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [lang, setLang] = useState("pt")

  const translations = {
    pt: {
      title: "Manuais",
      subtitle: "Acesse os manuais e documentação técnica",
      loading: "Carregando manuais...",
      noManuals: "Nenhum manual disponível no momento.",
      backToDashboard: "Voltar ao Dashboard",
      openManual: "Abrir Manual",
    },
    en: {
      title: "Manuals",
      subtitle: "Access manuals and technical documentation",
      loading: "Loading manuals...",
      noManuals: "No manuals available at the moment.",
      backToDashboard: "Back to Dashboard",
      openManual: "Open Manual",
    },
    es: {
      title: "Manuales",
      subtitle: "Accede a los manuales y documentación técnica",
      loading: "Cargando manuales...",
      noManuals: "No hay manuales disponibles en este momento.",
      backToDashboard: "Volver al Dashboard",
      openManual: "Abrir Manual",
    },
  }

  const t = (key: keyof typeof translations.pt) => {
    return translations[lang as keyof typeof translations][key] || key
  }

  useEffect(() => {
    const savedLang = localStorage.getItem("selectedLang") || "pt"
    setLang(savedLang)
    loadManuals()
  }, [])

  const loadManuals = async () => {
    try {
      setIsLoading(true)
      const response = await fetch("/api/marketing-manuals")
      const result = await response.json()

      if (result.success) {
        setManuals(result.data || [])
      } else {
        console.error("Error loading manuals:", result.error)
      }
    } catch (error) {
      console.error("Error loading manuals:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const getManualName = (manual: MarketingManual) => {
    switch (lang) {
      case "en":
        return manual.name_en
      case "pt":
        return manual.name_pt
      default:
        return manual.name_pt || manual.name_en
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div className="flex items-center">
              <Image src="/images/logo.png" alt="Drakkar Logo" width={120} height={40} className="mr-4" />
              <div>
                <h1 className="text-2xl font-bold text-gray-900">{t("title")}</h1>
                <p className="text-gray-600">{t("subtitle")}</p>
              </div>
            </div>
            <Link
              href="/dealer/dashboard"
              className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
            >
              {t("backToDashboard")}
            </Link>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
            <span className="ml-3 text-gray-600">{t("loading")}</span>
          </div>
        ) : manuals.length === 0 ? (
          <div className="text-center py-12">
            <div className="mx-auto h-12 w-12 text-gray-400">
              <Image src="/images/manual.png" alt="No manuals" width={48} height={48} className="opacity-50" />
            </div>
            <h3 className="mt-2 text-sm font-medium text-gray-900">{t("noManuals")}</h3>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {manuals.map((manual) => (
              <div
                key={manual.id}
                className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow duration-200"
              >
                <div className="p-6">
                  <div className="flex items-center mb-4">
                    <div className="flex-shrink-0">
                      <Image
                        src={manual.image_url || "/images/manual.png"}
                        alt={getManualName(manual)}
                        width={48}
                        height={48}
                        className="rounded-lg"
                      />
                    </div>
                    <div className="ml-4">
                      <h3 className="text-lg font-medium text-gray-900">{getManualName(manual)}</h3>
                    </div>
                  </div>

                  <div className="mt-4">
                    <a
                      href={manual.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors inline-flex items-center justify-center"
                    >
                      <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"
                        />
                      </svg>
                      {t("openManual")}
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
