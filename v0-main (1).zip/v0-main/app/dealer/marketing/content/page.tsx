"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import { useRouter } from "next/navigation"

interface MarketingContent {
  id: number
  title_en: string
  title_pt: string
  subtitle_en: string
  subtitle_pt: string
  image_url: string
  boat_model: string
  created_at: string
}

export default function MarketingContentPage() {
  const [content, setContent] = useState<MarketingContent[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [selectedModel, setSelectedModel] = useState("All Models")
  const [lang, setLang] = useState("en")
  const router = useRouter()

  useEffect(() => {
    const savedLang = localStorage.getItem("selectedLang") || "en"
    setLang(savedLang)
    loadContent()
  }, [])

  const loadContent = async () => {
    try {
      setIsLoading(true)
      const response = await fetch("/api/marketing-content")
      const result = await response.json()

      if (result.success) {
        setContent(result.data || [])
      } else {
        console.error("Error loading marketing content:", result.error)
      }
    } catch (error) {
      console.error("Error loading marketing content:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const filteredContent = content.filter(
    (item) => selectedModel === "All Models" || item.boat_model === selectedModel || item.boat_model === "All Models",
  )

  const getTitle = (item: MarketingContent) => {
    if (lang === "pt" && item.title_pt) {
      return item.title_pt
    }
    return item.title_en || ""
  }

  const getSubtitle = (item: MarketingContent) => {
    if (lang === "pt" && item.subtitle_pt) {
      return item.subtitle_pt
    }
    return item.subtitle_en || ""
  }

  const translations = {
    pt: {
      "Marketing Content": "Conteúdo de Marketing",
      "Filter by Model": "Filtrar por Modelo",
      "All Models": "Todos os Modelos",
      "No content available": "Nenhum conteúdo disponível",
      "Back to Marketing": "Voltar ao Marketing",
      Loading: "Carregando...",
    },
    en: {
      "Marketing Content": "Marketing Content",
      "Filter by Model": "Filter by Model",
      "All Models": "All Models",
      "No content available": "No content available",
      "Back to Marketing": "Back to Marketing",
      Loading: "Loading...",
    },
    es: {
      "Marketing Content": "Contenido de Marketing",
      "Filter by Model": "Filtrar por Modelo",
      "All Models": "Todos los Modelos",
      "No content available": "No hay contenido disponible",
      "Back to Marketing": "Volver al Marketing",
      Loading: "Cargando...",
    },
  }

  const t = (key: keyof (typeof translations)["en"]) => {
    return translations[lang as keyof typeof translations][key] || key
  }

  // Get unique boat models from content
  const boatModels = Array.from(new Set(content.map((item) => item.boat_model).filter(Boolean)))

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-gray-600">{t("Loading")}</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="bg-white p-6 rounded-lg shadow mb-6">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-4">
              <Image src="/images/logo.png" alt="Drakkar Logo" width={150} height={40} />
              <h1 className="text-2xl font-bold text-gray-800">{t("Marketing Content")}</h1>
            </div>
            <button
              onClick={() => router.push("/dealer/marketing")}
              className="bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700 font-medium"
            >
              {t("Back to Marketing")}
            </button>
          </div>
        </div>

        {/* Filter */}
        <div className="bg-white p-4 rounded-lg shadow mb-6">
          <div className="flex items-center gap-4">
            <label className="font-medium text-gray-700">{t("Filter by Model")}:</label>
            <select
              value={selectedModel}
              onChange={(e) => setSelectedModel(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-lg bg-white"
            >
              <option value="All Models">{t("All Models")}</option>
              {boatModels.map((model) => (
                <option key={model} value={model}>
                  {model}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Content Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredContent.length === 0 ? (
            <div className="col-span-full text-center py-12">
              <p className="text-gray-500 text-lg">{t("No content available")}</p>
            </div>
          ) : (
            filteredContent.map((item) => (
              <div key={item.id} className="bg-white rounded-lg shadow-lg overflow-hidden">
                <div className="relative h-48">
                  <Image
                    src={item.image_url || "/placeholder.svg?height=200&width=400"}
                    alt={getTitle(item)}
                    fill
                    className="object-cover"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement
                      target.src = "/placeholder.svg?height=200&width=400&text=Image+Not+Found"
                    }}
                  />
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold text-gray-800 mb-2">{getTitle(item)}</h3>
                  {getSubtitle(item) && <p className="text-gray-600 mb-4 line-clamp-3">{getSubtitle(item)}</p>}
                  <div className="flex justify-between items-center text-sm text-gray-500">
                    <span>{item.boat_model}</span>
                    <span>{new Date(item.created_at).toLocaleDateString()}</span>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  )
}
