"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import { useRouter } from "next/navigation"

export default function MarketingPage() {
  const [selectedLang, setSelectedLang] = useState("pt")
  const router = useRouter()

  const translations = {
    pt: {
      Marketing: "Marketing",
      "Marketing Materials": "Materiais de Marketing",
      "Access marketing content, images, and promotional materials for social media and advertising.":
        "Acesse conteúdo de marketing, imagens e materiais promocionais para redes sociais e publicidade.",
      "Marketing Content": "Conteúdo de Marketing",
      "Download images and copy titles/subtitles for social media":
        "Baixe imagens e copie títulos/subtítulos para redes sociais",
      "Product Manuals": "Manuais de Produtos",
      "Access technical documentation and user manuals": "Acesse documentação técnica e manuais do usuário",
      "Warranty Information": "Informações de Garantia",
      "View warranty terms and conditions": "Visualize termos e condições de garantia",
      "Back to Dashboard": "Voltar ao Dashboard",
    },
    en: {
      Marketing: "Marketing",
      "Marketing Materials": "Marketing Materials",
      "Access marketing content, images, and promotional materials for social media and advertising.":
        "Access marketing content, images, and promotional materials for social media and advertising.",
      "Marketing Content": "Marketing Content",
      "Download images and copy titles/subtitles for social media":
        "Download images and copy titles/subtitles for social media",
      "Product Manuals": "Product Manuals",
      "Access technical documentation and user manuals": "Access technical documentation and user manuals",
      "Warranty Information": "Warranty Information",
      "View warranty terms and conditions": "View warranty terms and conditions",
      "Back to Dashboard": "Back to Dashboard",
    },
    es: {
      Marketing: "Marketing",
      "Marketing Materials": "Materiales de Marketing",
      "Access marketing content, images, and promotional materials for redes sociales y publicidad.":
        "Accede a contenido de marketing, imágenes y materiales promocionales para redes sociales y publicidad.",
      "Marketing Content": "Contenido de Marketing",
      "Download images and copy titles/subtitles for social media":
        "Descarga imágenes y copia títulos/subtítulos para redes sociales",
      "Product Manuals": "Manuales de Productos",
      "Access technical documentation and user manuals": "Accede a documentación técnica y manuales de usuario",
      "Warranty Information": "Información de Garantía",
      "View warranty terms and conditions": "Ver términos y condiciones de garantía",
      "Back to Dashboard": "Volver al Dashboard",
    },
  }

  const t = (key: keyof (typeof translations)["pt"]) => {
    return translations[selectedLang as keyof typeof translations][key] || key
  }

  useEffect(() => {
    const savedLang = localStorage.getItem("selectedLang") || "pt"
    setSelectedLang(savedLang)
  }, [])

  const marketingOptions = [
    {
      title: t("Marketing Content"),
      description: t("Download images and copy titles/subtitles for social media"),
      icon: "/images/conteudo.png",
      href: "/dealer/marketing/content",
      bgColor: "bg-blue-500",
    },
    {
      title: t("Product Manuals"),
      description: t("Access technical documentation and user manuals"),
      icon: "/images/manual.png",
      href: "/dealer/marketing/manuais",
      bgColor: "bg-green-500",
    },
    {
      title: t("Warranty Information"),
      description: t("View warranty terms and conditions"),
      icon: "/images/garantia.png",
      href: "#",
      bgColor: "bg-purple-500",
    },
  ]

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <div className="max-w-7xl mx-auto">
        <div className="bg-white p-6 rounded-lg shadow mb-8">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-3xl font-bold text-gray-800 mb-2">{t("Marketing Materials")}</h1>
              <p className="text-gray-600">
                {t("Access marketing content, images, and promotional materials for social media and advertising.")}
              </p>
            </div>
            <button
              onClick={() => router.push("/dealer/dashboard")}
              className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
            >
              ← {t("Back to Dashboard")}
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {marketingOptions.map((option, index) => (
            <div
              key={index}
              onClick={() => option.href !== "#" && router.push(option.href)}
              className={`bg-white rounded-lg shadow-lg overflow-hidden transition-transform hover:scale-105 ${
                option.href !== "#" ? "cursor-pointer" : "cursor-not-allowed opacity-75"
              }`}
            >
              <div className={`${option.bgColor} p-6 text-center`}>
                <div className="w-16 h-16 mx-auto mb-4 bg-white rounded-full flex items-center justify-center">
                  <Image
                    src={option.icon || "/placeholder.svg"}
                    alt={option.title}
                    width={32}
                    height={32}
                    className="object-contain"
                  />
                </div>
                <h3 className="text-xl font-bold text-white">{option.title}</h3>
              </div>
              <div className="p-6">
                <p className="text-gray-600 text-center">{option.description}</p>
                {option.href === "#" && <p className="text-sm text-gray-400 text-center mt-2 italic">Em breve</p>}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
