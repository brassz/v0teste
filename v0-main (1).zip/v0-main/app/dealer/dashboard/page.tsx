"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Notification, useNotification } from "@/components/notification"
import Image from "next/image"
import Link from "next/link"

export default function Dashboard() {
  const [lang, setLang] = useState<"pt" | "en" | "es">("pt")
  const [showPasswordModal, setShowPasswordModal] = useState(false)
  const [passwordForm, setPasswordForm] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  })
  const [isChangingPassword, setIsChangingPassword] = useState(false)

  useEffect(() => {
    const savedLang = localStorage.getItem("selectedLang")
    if (savedLang && ["pt", "en", "es"].includes(savedLang)) {
      setLang(savedLang as "pt" | "en" | "es")
    }
  }, [])

  const translations = {
    pt: {
      "DEALER DASHBOARD": "PAINEL DO DISTRIBUIDOR",
      "NEW BOATS": "NOVOS BARCOS",
      "TRACK ORDERS": "ACOMPANHAR PEDIDOS",
      "AFTER-SALES SERVICE": "SERVIÇO PÓS-VENDA",
      SALES: "VENDAS",
      "QUOTE CLIENT": "ORÇAMENTO CLIENTE",
      MARKETING: "MARKETING",
      "THE LEGEND OF THE VIKINGS": "A LENDA DOS VIKINGS",
      "CHANGE PASSWORD": "ALTERAR SENHA",
      "Current Password": "Senha Atual",
      "New Password": "Nova Senha",
      "Confirm New Password": "Confirmar Nova Senha",
      Cancel: "Cancelar",
      Change: "Alterar",
    },
    en: {
      "DEALER DASHBOARD": "DEALER DASHBOARD",
      "NEW BOATS": "NEW BOATS",
      "TRACK ORDERS": "TRACK ORDERS",
      "AFTER-SALES SERVICE": "AFTER-SALES SERVICE",
      SALES: "SALES",
      "QUOTE CLIENT": "QUOTE CLIENT",
      MARKETING: "MARKETING",
      "THE LEGEND OF THE VIKINGS": "THE LEGEND OF THE VIKINGS",
      "CHANGE PASSWORD": "CHANGE PASSWORD",
      "Current Password": "Current Password",
      "New Password": "New Password",
      "Confirm New Password": "Confirm New Password",
      Cancel: "Cancel",
      Change: "Change",
    },
    es: {
      "DEALER DASHBOARD": "PANEL DEL DISTRIBUIDOR",
      "NEW BOATS": "NUEVOS BARCOS",
      "TRACK ORDERS": "SEGUIMIENTO DE PEDIDOS",
      "AFTER-SALES SERVICE": "SERVICIO POSTVENTA",
      SALES: "VENTAS",
      "QUOTE CLIENT": "COTIZACIÓN CLIENTE",
      MARKETING: "MARKETING",
      "THE LEGEND OF THE VIKINGS": "LA LEYENDA DE LOS VIKINGOS",
      "CHANGE PASSWORD": "CAMBIAR CONTRASEÑA",
      "Current Password": "Contraseña Actual",
      "New Password": "Nueva Contraseña",
      "Confirm New Password": "Confirmar Nueva Contraseña",
      Cancel: "Cancelar",
      Change: "Cambiar",
    },
  } as const

  const handlePasswordChange = async (e: React.FormEvent) => {
    e.preventDefault()

    if (passwordForm.newPassword !== passwordForm.confirmPassword) {
      showNotification(
        lang === "pt"
          ? "As senhas não coincidem"
          : lang === "en"
            ? "Passwords don't match"
            : "Las contraseñas no coinciden",
        "error",
      )
      return
    }

    if (passwordForm.newPassword.length < 4) {
      showNotification(
        lang === "pt"
          ? "A nova senha deve ter pelo menos 4 caracteres"
          : lang === "en"
            ? "New password must be at least 4 characters"
            : "La nueva contraseña debe tener al menos 4 caracteres",
        "error",
      )
      return
    }

    setIsChangingPassword(true)

    try {
      const dealerId = localStorage.getItem("currentDealerId")
      const response = await fetch("/api/change-dealer-password", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          dealerId,
          currentPassword: passwordForm.currentPassword,
          newPassword: passwordForm.newPassword,
        }),
      })

      const data = await response.json()

      if (data.success) {
        showNotification(
          lang === "pt"
            ? "Senha alterada com sucesso!"
            : lang === "en"
              ? "Password changed successfully!"
              : "¡Contraseña cambiada exitosamente!",
          "success",
        )
        setShowPasswordModal(false)
        setPasswordForm({ currentPassword: "", newPassword: "", confirmPassword: "" })
      } else {
        showNotification(
          data.error ||
            (lang === "pt"
              ? "Erro ao alterar senha"
              : lang === "en"
                ? "Error changing password"
                : "Error al cambiar contraseña"),
          "error",
        )
      }
    } catch (error) {
      showNotification(
        lang === "pt"
          ? "Erro ao alterar senha"
          : lang === "en"
            ? "Error changing password"
            : "Error al cambiar contraseña",
        "error",
      )
    } finally {
      setIsChangingPassword(false)
    }
  }

  const { notification, showNotification, hideNotification } = useNotification()
  const t = translations[lang]

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Blue Header - Darker blue like home page */}
      <div className="bg-blue-900 py-6 px-8">
        <div className="flex justify-center items-center max-w-7xl mx-auto">
          <Image
            src="/images/logodashboard.png"
            alt="Drakkar Boats Logo"
            width={200}
            height={60}
            className="h-12 w-auto"
          />
        </div>
      </div>

      {/* Change Password Button */}
      <div className="py-4 px-8">
        <div className="max-w-6xl mx-auto flex justify-end">
          <button
            onClick={() => setShowPasswordModal(true)}
            className="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-lg font-medium transition-colors duration-200 shadow-lg"
          >
            {t["CHANGE PASSWORD"]}
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="py-12 px-8">
        <div className="max-w-6xl mx-auto">
          {/* Title */}
          <h1 className="text-4xl font-bold text-blue-900 text-center mb-12">{t["DEALER DASHBOARD"]}</h1>

          {/* First Row - 3 Large Cards - Darker blue */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
            {/* New Boats */}
            <Link href="/dealer/new-boat" className="group">
              <div className="bg-blue-900 hover:bg-blue-950 rounded-2xl p-8 text-center transition-colors duration-200">
                <div className="mb-4">
                  <Image src="/images/new-boats.png" alt="New Boats" width={80} height={80} className="mx-auto" />
                </div>
                <h3 className="text-white text-lg font-bold">{t["NEW BOATS"]}</h3>
              </div>
            </Link>

            {/* Track Orders */}
            <Link href="/dealer/track-orders" className="group">
              <div className="bg-blue-900 hover:bg-blue-950 rounded-2xl p-8 text-center transition-colors duration-200">
                <div className="mb-4">
                  <Image src="/images/track-orders.png" alt="Track Orders" width={80} height={80} className="mx-auto" />
                </div>
                <h3 className="text-white text-lg font-bold">{t["TRACK ORDERS"]}</h3>
              </div>
            </Link>

            {/* After-Sales Service */}
            <Link href="/dealer/after-sales" className="group">
              <div className="bg-blue-900 hover:bg-blue-950 rounded-2xl p-8 text-center transition-colors duration-200">
                <div className="mb-4">
                  <Image src="/images/after-sales.png" alt="After Sales" width={80} height={80} className="mx-auto" />
                </div>
                <h3 className="text-white text-lg font-bold">{t["AFTER-SALES SERVICE"]}</h3>
              </div>
            </Link>
          </div>

          {/* Second Row - 3 Cards - Darker blue */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
            {/* Sales */}
            <Link href="/dealer/sales" className="group">
              <div className="bg-blue-900 hover:bg-blue-950 rounded-2xl p-6 text-center transition-colors duration-200">
                <div className="mb-3">
                  <Image src="/images/venda.png" alt="Sales" width={60} height={60} className="mx-auto" />
                </div>
                <h3 className="text-white text-sm font-bold">{t.SALES}</h3>
              </div>
            </Link>

            {/* Quote Client */}
            <Link href="/dealer/quote-client" className="group">
              <div className="bg-blue-900 hover:bg-blue-950 rounded-2xl p-6 text-center transition-colors duration-200">
                <div className="mb-3">
                  <Image src="/images/quoteclient.png" alt="Quote Client" width={60} height={60} className="mx-auto" />
                </div>
                <h3 className="text-white text-sm font-bold">{t["QUOTE CLIENT"]}</h3>
              </div>
            </Link>

            {/* Marketing */}
            <Link href="/dealer/marketing" className="group">
              <div className="bg-blue-900 hover:bg-blue-950 rounded-2xl p-6 text-center transition-colors duration-200">
                <div className="mb-3">
                  <Image src="/images/marketing.png" alt="Marketing" width={60} height={60} className="mx-auto" />
                </div>
                <h3 className="text-white text-sm font-bold">{t.MARKETING}</h3>
              </div>
            </Link>
          </div>

          {/* Bottom Section with Dragon */}
          <div className="relative">
            <div className="text-center">
              <h2 className="text-3xl font-bold text-blue-900 mb-8">{t["THE LEGEND OF THE VIKINGS"]}</h2>
            </div>

            {/* Dragon positioned to the right */}
            <div className="absolute right-0 top-0 hidden lg:block">
              <Image src="/images/dragon.png" alt="Dragon" width={200} height={150} className="opacity-80" />
            </div>
          </div>
        </div>
      </div>

      {/* Password Change Modal */}
      {showPasswordModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md mx-4">
            <h2 className="text-xl font-bold text-gray-800 mb-4">{t["CHANGE PASSWORD"]}</h2>
            <form onSubmit={handlePasswordChange} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">{t["Current Password"]}</label>
                <input
                  type="password"
                  value={passwordForm.currentPassword}
                  onChange={(e) => setPasswordForm((prev) => ({ ...prev, currentPassword: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">{t["New Password"]}</label>
                <input
                  type="password"
                  value={passwordForm.newPassword}
                  onChange={(e) => setPasswordForm((prev) => ({ ...prev, newPassword: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                  minLength={4}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">{t["Confirm New Password"]}</label>
                <input
                  type="password"
                  value={passwordForm.confirmPassword}
                  onChange={(e) => setPasswordForm((prev) => ({ ...prev, confirmPassword: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                  minLength={4}
                />
              </div>
              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => {
                    setShowPasswordModal(false)
                    setPasswordForm({ currentPassword: "", newPassword: "", confirmPassword: "" })
                  }}
                  className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50 transition-colors"
                >
                  {t["Cancel"]}
                </button>
                <button
                  type="submit"
                  disabled={isChangingPassword}
                  className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50 transition-colors"
                >
                  {isChangingPassword ? "..." : t["Change"]}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Notification */}
      <Notification
        message={notification.message}
        type={notification.type}
        isVisible={notification.isVisible}
        onClose={hideNotification}
      />
    </div>
  )
}
